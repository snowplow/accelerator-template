+++
title = "Page Example"
weight = 4
+++

This is an example of an Accelerator Page

{{%attachments style="blue"/%}}

