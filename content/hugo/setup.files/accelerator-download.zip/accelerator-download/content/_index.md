+++
title = "Snowplow Accelerator"
menuTitle="Introduction"
chapter = false
weight = 1
+++

This is an example of an Accelerator Introduction